﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace DS_P1_showInSerialPort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] ports = System.IO.Ports.SerialPort.GetPortNames();
        bool boolButtonSetPorts, boolButtonSetBaudrate = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            for (int i = 0; i < ports.Length; i++)
            {
                string inCombo = ports[i];
                comboBox1.Items.Add(inCombo);
            }
            if (comboBox1.Items.Count > 0)
                comboBox1.Text = comboBox1.Items[0].ToString();
        }
        private void Refresh_Click(object sender, EventArgs e)
        {
            if (buttonOpen.Text == "open")
            {
                comboBox1.Items.Clear();
                for (int i = 0; i < ports.Length; i++)
                {
                    string inCombo = ports[i];
                    comboBox1.Items.Add(inCombo);
                }
                if (comboBox1.Items.Count > 0)
                    comboBox1.Text = comboBox1.Items[0].ToString();
                buttonSetPorts.BackColor = Color.OldLace;
                buttonSetBaudrate.BackColor = Color.OldLace;
                numericUpDown1.Value = 0;
            }
            else
                MessageBox.Show("port is open please close the port !!!", " ▒▒▒▒▒▒▒▒ error ▒▒▒▒▒▒▒▒", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        void doOnOpen()
        {
            this.Text = "Opened   -->" + serialPort1.PortName;
            buttonOpen.Text = "close";
        }
        void doOnClose()
        {
            this.Text = "Closed   -->" + serialPort1.PortName;
            buttonOpen.Text = "open";
            buttonSetPorts.BackColor = Color.OldLace;
            buttonSetBaudrate.BackColor = Color.OldLace;
        }
        private void ButtonSetBaudrate_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value > 1000000000000 || numericUpDown1.Value == 0 || numericUpDown1.Value < 0)
            {
                MessageBox.Show("it's out of range", "▒▒▒▒ out of range ▒▒▒▒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                numericUpDown1.Value = 0;
            }
            else
            {
                boolButtonSetBaudrate = true;
                buttonSetBaudrate.BackColor = Color.DarkCyan;
            }
        }
        private void ButtonSetPorts_Click(object sender, EventArgs e)
        {
            boolButtonSetPorts = true;
            buttonSetPorts.BackColor = Color.DarkCyan;
        }
        private void NumericUpDown1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (numericUpDown1.Value > 1000000000000 || numericUpDown1.Value == 0 || numericUpDown1.Value < 0)
                {
                    MessageBox.Show("it's out of range", "▒▒▒▒ out of range ▒▒▒▒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    numericUpDown1.Value = 0;
                }
                else
                {
                    boolButtonSetBaudrate = true;
                    buttonSetBaudrate.BackColor = Color.DarkCyan;
                }
            }
        }

        private void ComboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                boolButtonSetPorts = true;
                buttonSetPorts.BackColor = Color.DarkCyan;
            }
        }

        private void ButtonOpen_Click(object sender, EventArgs e)
        {
            bool isPortExist = false;
            if (boolButtonSetBaudrate == true && boolButtonSetPorts == true)
            {
                if (buttonOpen.Text == "open")
                {
                    for (int i = 0; i < ports.Length; i++)
                    {
                        if (ports[i] == comboBox1.Text)
                        {
                            isPortExist = true;
                            break;
                        }
                    }
                    if (isPortExist)
                    {
                        serialPort1.PortName = comboBox1.Text;
                        serialPort1.BaudRate = (int)numericUpDown1.Value;
                        serialPort1.Open();

                        doOnOpen();
                    }
                    else
                        MessageBox.Show("Port not exist please refresh ports and try again", "▒▒▒▒▒▒▒▒▒▒ not exist ▒▒▒▒▒▒▒▒▒▒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    serialPort1.Close();
                    doOnClose();
                }
            }
            else
            {
                MessageBox.Show("please ser Ports or Baudrate !!!", "▒▒▒▒▒▒ do sets ▒▒▒▒▒▒", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }
    }
}
